package assignment7.enums;

public enum Genres {

	COMEDY, DRAMA, ACTION, THRILLER, HORROR, BIOGRAPHY
}
