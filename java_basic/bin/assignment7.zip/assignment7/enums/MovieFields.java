package assignment7.enums;

public enum MovieFields {

	TITLE, DIRECTOR, RELEASE_YEAR, COUNTRY, DURATION
}
